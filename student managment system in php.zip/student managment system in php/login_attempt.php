 
   <?php 
     
    include"dbcon.php";                 // include the directory of establish the connection
  	$user_name=$_POST['user_name'];     // taking the text field value in php variable
	$password=$_POST['password'];
	$designation=$_POST['designation'];	
	
	$login="SELECT * FROM login WHERE id='$user_name' AND password='$password' AND designation='$designation'"; // pass the query
	$log_query=$conn->query($login);    // execute the query
	
		if($log_query->num_rows==1)       // check that table is empty or greater than 1 value
	   {   
	        $row=$log_query->fetch_assoc();
			$user_name=$row['user_name'];
			$designation=$row['designation'];
			if($designation=="Admin")                  // if login person is manager then its location is set of that page
			{ header("location:admin_panel.php");

			}
			else if($designation=="Student")	
	         { 
		      header("location:student.php");
             }
		}	
		else
		{
			echo"User Does Not Exist";
		}
    ?>
