<?php
include "dbcon.php";
$fn=$_POST['f_name'];
$ln=$_POST['l_name'];
$id=$_POST['id'];
$phone=$_POST['phone'];
$add=$_POST['adress'];
$deg=$_POST['degree'];


				          
	$insert="Insert into student_info( f_name,l_name,id,phone,adress,degree) VALUES('$fn','$ln','$id','$phone','$add','$deg')"; // insert into db
	//$insert_query=$conn->query($insert);
	    
     if ($conn->query($insert) === TRUE) // query execution and check data enter succeesfull
	    {
       // echo "New record created successfully";
		header("location:add_student.php");
		}  
		else 
		{
       echo "Error: " . $insert . "<br>" . $conn->error;
     }
			
	
	
	
?> 