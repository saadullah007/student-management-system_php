

<!DOCTYPE html>
<html>
<head>
<title>Student Portal</title>
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
<!-- jQuery (Bootstrap's JavaScript plugins) -->
<script src="js/jquery.min.js"></script>
<!-- Custom Theme files -->
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<!-- Custom Theme files -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Spicy Cuisine Responsive web template, Bootstrap Web Templates, Flat Web Templates, Andriod Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyErricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!--webfont-->
<link href='http://fonts.googleapis.com/css?family=Raleway:400,200,100,300,500,600,700,800,900' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Source+Sans+Pro:200,300,400,600,700,900,300italic,400italic,600italic,700italic' rel='stylesheet' type='text/css'>
<!---- start-smoth-scrolling---->
		<script type="text/javascript" src="js/move-top.js"></script>
		<script type="text/javascript" src="js/easing.js"></script>
		<script type="text/javascript">
			jQuery(document).ready(function($) {
				$(".scroll").click(function(event){		
					event.preventDefault();
					$('html,body').animate({scrollTop:$(this.hash).offset().top},900);
				});
			});
		</script>
<!---- start-smoth-scrolling---->
<!--animated-css-->
<link href="css/animate.css" rel="stylesheet" type="text/css" media="all">
<script src="js/wow.min.js"></script>
<script>
 new WOW().init();
</script>
<!--/animated-css-->

</head>
<body>
<!---->
<div class="banner">
	 <div class="container">
		 <div class="header">
			 <div class="logo wow fadeInLeft" data-wow-delay="0.5s">
			 <a href="login.php"><img src="images/images.jpg" alt=""/></a>			 </div>
			 <div class="top-menu">
			 <span class="menu"></span>
				 <ul>
				 <li ><a href="add_student.php">Add New Record</a></li>
                 <li ><a href="employee_info_display.php">Student Information</a></li>				 
				
                 
                 
                 </ul>
			 </div>
			  <!-- script-for-menu -->
		 <script>
				$("span.menu").click(function(){
					$(".top-menu ul").slideToggle("slow" , function(){
					});
				});
		 </script>
		 <!-- script-for-menu -->	  	

			 <div class="clearfix"></div>
		 </div>
		 </div>
              </div>
			 <div class="clearfix"></div>
		 </div>
	 </div>
</div>
	     			<!---------->
<div class="footer text-center">
	 <div class="container">		
		<!-- <a class="wow bounceIn" data-wow-delay="0.5s" href="index.html"><img src="images/logo2.png" alt=""/></a>	-->	 
		 <p class="wow bounceIn" data-wow-delay="0.4s">Copyright &copy; 2015 UMT All rights reserved | Design by  <a href="login.php"> Usman Ahmad Kayani</a></p>
		 <div class="social">			 
			 <a href="#"><span class="behance"></span></a>
			 <a href="#"><span class="dribble"></span></a>
			 <a href="#"><span class="twitter"></span></a>
			 <a href="#"><span class="facebook"></span></a>
			 <a href="#"><span class="linkedin"></span></a>
		 </div>
	 </div>	
</div>
<!---->
<script type="text/javascript">
		$(document).ready(function() {
				/*
				var defaults = {
				containerID: 'toTop', // fading element id
				containerHoverID: 'toTopHover', // fading element hover id
				scrollSpeed: 1200,
				easingType: 'linear' 
				};
				*/
		$().UItoTop({ easingType: 'easeOutQuart' });
});
</script>
<a href="#to-top" id="toTop" style="display: block;"> <span id="toTopHover" style="opacity: 1;"> </span></a>
<!---->
</body>
</html>